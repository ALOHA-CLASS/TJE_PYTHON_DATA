-- Active: 1712576329756@@127.0.0.1@3306@joeun
SELECT *
FROM 학생
;
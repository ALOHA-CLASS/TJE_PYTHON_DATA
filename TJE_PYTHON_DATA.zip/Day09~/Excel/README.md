# 예제 리스트

| 순번 | 교재 | 실습 | 입력 | 내용 |
|-----|-----|-----|-----|-----|
| 1 | 1excel_introspect_workbook.py | 01_엑셀입력.py | sales_2013.xlsx | 엑셀 파일 읽기 |
| 2 | 2excel_parsing_and_write.py | 02_엑셀입출력.py | sales_2013.xlsx| 엑셀 파일 입출력 |
| 3 | 3excel_parsing_and_write_keep_dates.py | 03_엑셀_날짜형식.py | sales_2013.xlsx| 날짜 형식 할당 |
| 4 | pandas_parsing_and_write_keep_dates.py | 04_pandas_엑셀_날짜형식.py | sales_2013.xlsx| pandas 날짜 형식 할당 |
| 5 | 4excel_value_meets_condition.py | 05_특정행_필터링.py | sales_2013.xlsx| 조건으로 특정행 필터링 |
| 6 | pandas_value_meets_condition.py | 06_pandas_특정행_필터링.py | sales_2013.xlsx| pandas 조건으로 특정행 필터링 |
| 7 | 5excel_value_in_set.py | 07_집합으로_필터링.py | sales_2013.xlsx| 집합으로 특정행 필터링 |
| 8 | pandas_value_in_set.py | 08_pandas_집합으로_필터링.py | sales_2013.xlsx| pandas 집합으로 특정행 필터링 |
| 9 | 6excel_value_matches_pattern.py | 09_정규표현식으로_필터링.py | sales_2013.xlsx| 정규표현식으로 특정행 필터링 |
| 10 | pandas_value_matches_pattern.py | 10_pandas_정규표현식으로_필터링.py | sales_2013.xlsx| pandas 정규표현식으로 특정행 필터링 |
| 11 | 7excel_column_by_index.py | 11_index로_열선택.py | sales_2013.xlsx| index로 특정 열 선택 |
| 12 | pandas_column_by_index.py | 12_pandas_index로_열선택.py | sales_2013.xlsx| pandas index로 특정 열 선택 |
| 13 | 8excel_column_by_name.py | 13_헤더로_열선택.py | sales_2013.xlsx| 헤더로 특정 열 선택 |
| 14 | pandas_column_by_name.py | 14_pandas_헤더로_열선택.py | sales_2013.xlsx| pandas 헤더로 특정 열 선택 |
| 15 | 9excel_value_meets_condition_all_worksheets.py | 15_모든worksheet_특정행_필터링.py | sales_2013.xlsx| 모든 worksheet 특정 행 필터링 |
| 16 | pandas_value_meets_condition_all_worksheets.py | 16_pandas_모든worksheet_특정행_필터링.py | sales_2013.xlsx| pandas 모든 worksheet 특정 행 필터링 |
| 17 | 10excel_column_by_name_all_worksheets.py | 17_모든worksheet_특정열_선택.py | sales_2013.xlsx| 모든 worksheet 특정 열 선택 |
| 18 | pandas_column_by_name_all_worksheets.py | 18_pandas_모든worksheet_특정열_선택.py | sales_2013.xlsx| pandas 모든 worksheet 특정 열 선택 |
| 19 | 11excel_value_meets_condition_set_of_worksheets.py | 19_모든worksheet_집합으로_특정행_필터링.py | sales_2013.xlsx| 모든 worksheet 집합으로 특정 행 필터링 |
| 20 | pandas_value_meets_condition_set_of_worksheets.py | 20_pandas_모든worksheet_집합으로_특정행_필터링.py | sales_2013.xlsx| pandas 모든 worksheet 집합으로 특정 행 필터링 |
| 21 | 12excel_introspect_all_workbooks.py | 21_통합문서_행열개수.py | sales_2013.xlsx| 통합 문서, 행, 열 개수 |
| 22 | 13excel_concat_data_from_multiple_workbooks.py | 22_여러통합문서_병합.py | sales_2013.xlsx| 여러 통합 문서 병합 |
| 23 | pandas_concat_data_from_multiple_workbooks.py | 23_pandas_여러통합문서_병합.py | sales_2013.xlsx| pandas 여러 통합 문서 병합 |
| 24 | 14excel_sum_average_multiple_workbooks.py | 24_통합문서_합계평균.py | sales_2013.xlsx| 통합문서, 워크시트별 합계 및 평균 |
| 25 | pandas_sum_average_multiple_workbooks.py | 25_pandas_통합문서_합계평균.py | sales_2013.xlsx| pandas 통합문서, 워크시트별 합계 및 평균


# 변수 선언
a = 10
b = 12.34
c = '김조은'

# 자료형 확인
print( type(a) )
print( type(b) )
print( type(c) )

x = 10
y = 20

# 다중 커서         : alt + 마우스 클릭
# 다중 커서 해제    : esc
print("x + y = ", x + y)
print("x - y = ", x - y)
print("x * y = ", x * y)
print("x / y = ", x / y)
print("x % y = ", x % y)

# 정수 나누기
m = 10
n = 3
print("m // n = ", m // n)

# 제곱
i = 2
j = 3
print("2의 3제곱 : ", i ** j)

# 연산자는 곱셉, 나눗셈이 덧셈, 뺄셈보다 우선한다.
print(" 1 + 2 * 3 = ", 1 + 2 * 3)
print("(1 + 2) * 3 = ", (1 + 2) * 3)
print("1 + (2 * 3) = ", 1 + (2 * 3))
# 복합 대입 연산자
A = 10
A += 1                      # A = A + 1
print("A += 1 : ", A)       # 11

A -= 1                      # A = A - 1
print("A -= 1 : ", A)       # 10

A *= 2                      # A = A * 2
print("A *= 2 : ", A)       # 20

A /= 2                      # A = A / 2
print("A /= 2 : ", A)       # 10


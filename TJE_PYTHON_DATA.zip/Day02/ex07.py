name = '김조은'
print('내 이름은 %s 입니다.' % name)

height = 180.24123
print('내 키는 %.2f cm 입니다.' % height)

weight = 70.5
print('내 몸무게는 %.2f kg 입니다.' % weight)

year,month,day = 2023,1,17
print('내 생일은 %d년 %d월 %d일 입니다.' %(year,month,day))
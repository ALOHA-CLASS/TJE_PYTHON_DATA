
A = input("A : ")
B = input("B : ")
# input 함수는 값을 입력받아 문자열(str)로 가져온다

A = int(A)
B = int(B)

print("A + B = ",A + B)